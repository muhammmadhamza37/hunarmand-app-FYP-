import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hunarmand_app/screens/plumber_screen.dart';
import 'package:hunarmand_app/screens/worker_detail_screen.dart';

import 'electrician_screen.dart';
import 'home_screen.dart';
class MechanicScreen extends StatefulWidget {
  const MechanicScreen({Key? key}) : super(key: key);

  @override
  State<MechanicScreen> createState() => _MechanicScreenState();
}

class _MechanicScreenState extends State<MechanicScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        items: [

          BottomNavigationBarItem(
              icon: IconButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) =>  HomeScreen()));
                  },
                  icon: Icon(Icons.home)),
              label: 'Home'),

          BottomNavigationBarItem(
              icon: IconButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const MechanicScreen()));
                  },
                  icon: Icon(Icons.car_rental)),
              label: 'Mechanics'),
          BottomNavigationBarItem(
              icon: IconButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const PlumberScreen()));
                  },
                  icon: Icon(Icons.plumbing_rounded)),
              label: 'Plumbers'),
          BottomNavigationBarItem(
              icon: IconButton(
                  onPressed: () {
                    Navigator.of(context).push(MaterialPageRoute(
                        builder: (context) => const ElectricianScreen()));
                  },
                  icon: Icon(Icons.electric_bolt_outlined)),
              label: 'Electricians'),
        ],
      ),
      appBar: AppBar(
        title: const Text('Mechanics'),
      ),
      body: StreamBuilder(
        stream: FirebaseFirestore.instance.collection('workers').where("skill", isEqualTo: 'Mechanic').snapshots(),
        builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot){


          if(snapshot.hasData)
            {

              final data = snapshot.data;
              List<DocumentSnapshot> documentSnapshot = data!.docs;

              return Container(
                width: double.infinity,
                height: double.infinity,
                color: Colors.white,
                child: ListView.builder(
                  itemCount: documentSnapshot.length,
                    itemBuilder: (context, int index){

                    return GestureDetector(
                      onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(builder: (context){
                          return WorkerDetailScreen(uid: documentSnapshot[index]['uid'],);
                        }));
                      },
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Container(
                          height: 80,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Colors.grey.shade200,
                            border: Border.all(color: Colors.grey.shade200),
                            boxShadow: [
                              BoxShadow(
                              color: Colors.grey,
                                blurRadius: 25,
                                spreadRadius: 2,
                                offset: Offset(2,2)

                            )]
                          ),
                          child: ListTile(
                            leading: CircleAvatar(
                              backgroundImage: NetworkImage(documentSnapshot[index]['imageUrl']),
                            ),

                            title: Text(documentSnapshot[index]['firstName']),
                            subtitle:Text(documentSnapshot[index]['skill']) ,
                            trailing: Icon(Icons.add_circle_outline),
                          ),
                        ),
                      ),
                    );

                    }),
              );
            }
          else
            {
              return Container();
            }
        },

      ),
    );
  }
}

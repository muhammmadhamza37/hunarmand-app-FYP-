import 'package:flutter/material.dart';

import 'auth.dart';
class WorkerRequestScreen extends StatefulWidget {
  const WorkerRequestScreen({Key? key}) : super(key: key);

  @override
  State<WorkerRequestScreen> createState() => _WorkerRequestScreenState();
}

class _WorkerRequestScreenState extends State<WorkerRequestScreen> {

  final auth = AuthUser();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title:const Text('Worker Request'),
      ),
      body: Center(child: ElevatedButton(onPressed: (){
        auth.signOut(context);
      }, child: Text("logout"),),),
    );
  }
}

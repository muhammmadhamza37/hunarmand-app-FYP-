import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class WorkerDetailScreen extends StatefulWidget {
  const WorkerDetailScreen({Key? key, required this.uid}) : super(key: key);

  final String uid;

  @override
  State<WorkerDetailScreen> createState() => _WorkerDetailScreenState();
}

class _WorkerDetailScreenState extends State<WorkerDetailScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection("workers")
              .doc(widget.uid)
              .snapshots(),
          builder: (BuildContext context, AsyncSnapshot snapshot) {
            final data = snapshot.data;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 75, left: 95),
                  child: Container(
                    width: 150,
                    height: 150,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.deepOrange,
                        image: DecorationImage(
                            image: NetworkImage(data['imageUrl']))),
                  ),
                ),

                Text(data['firstName']),
                Text(data['city']),
              ],
            );
          },
        ),
      ),
    );

    // return Scaffold(
    //   body: Column(
    //     crossAxisAlignment: CrossAxisAlignment.center,
    //     children: [
    //       Padding(
    //         padding: const EdgeInsets.only(top: 75,left: 95),
    //         child: Container(
    //           width: 150,
    //           height: 150,
    //          alignment: Alignment.center,
    //          decoration: BoxDecoration(
    //            shape: BoxShape.circle,
    //            color: Colors.deepOrange,
    //            image: DecorationImage(image: AssetImage('assets/images/profile.jpg'))
    //          ),
    //         ),
    //       ),
    //     ],
    //   ),
    // );
  }
}

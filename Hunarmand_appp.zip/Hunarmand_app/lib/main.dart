import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:hunarmand_app/screens/home_screen.dart';
import 'package:hunarmand_app/screens/login_screen.dart';
import 'package:hunarmand_app/screens/sign_up_screen.dart';
import 'package:hunarmand_app/screens/splash_sceen.dart';
import 'package:hunarmand_app/screens/worker_request_screen.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  final db = FirebaseFirestore.instance;
  final auth = FirebaseAuth.instance;

  bool workerExist = false;
  bool clientExist = false;
  bool loading = false;
  getUser()async
  {
    final worker =await db.collection("workers").doc(auth.currentUser!.uid).get();
    final client =await db.collection("client").doc(auth.currentUser!.uid).get();
    bool isWorker = worker.exists;
    bool isClient = client.exists;

    if(isWorker)
      {
        setState(() {
          workerExist = true;
        });
      }
    else if(isClient)
      {
        setState(() {
          clientExist = true;
        });
      }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUser();
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: FirebaseAuth.instance.currentUser == null ? const LoginScreen() :
      workerExist ? const WorkerRequestScreen() :
      clientExist ? HomeScreen() : null,
      // home: loading ? FirebaseAuth.instance.currentUser == null
      //     ? const LoginScreen() : isWorker! ? const WorkerRequestScreen() : HomeScreen() : Center(child: CircularProgressIndicator(),),
    );
  }
}





